# TranslucentTabs Studio ✨
> Modern Windows Explorer Blur, Acrylic & Mica Manager with a Fluent UI / UX Pro Max interface.

Powered by [Maplespe/ExplorerBlurMica](https://github.com/Maplespe/ExplorerBlurMica).

---

## 🌟 Overview

**TranslucentTabs Studio** provides an intuitive, modern desktop interface to enable, customize, and revert transparency effects on **Windows File Explorer** for Windows 10 and Windows 11.

- **Do (Apply Blur Effect):** One-click registration and File Explorer restart with your customized transparency parameters.
- **Undo (Revert Effect):** One-click unregistration restoring the stock, native Windows File Explorer look without leftover hooks.
- **Live Preview & RGBA Studio:** Real-time opacity and color blending sliders for both Dark and Light modes.
- **Quick Links Integration:** Dedicated buttons to your **GitHub Page**, **Personal Website**, and the upstream repository.
- **Modern UI / UX Pro Max Design:** Frosted glassmorphism, responsive controls, crisp vector SVG icons, smooth transitions, and dark/light mode toggle.

---

## 🚀 Quick Start

### 1. Launch the App
Double-click either launcher script in the project folder:
* **`run.bat`**: Standard launcher (opens in Edge App Mode or default browser; elevates via UAC when applying/undoing).
* **`run_admin.bat`**: Launches directly with Administrator privileges.

Alternatively, from the terminal:
```powershell
python app.py
```

### 2. Apply or Undo Blur
1. **Choose your desired Effect Mode**:
   - `0` - **Blur**: Classic Gaussian blur (Win10 / early Win11).
   - `1` - **Acrylic**: Fluent frosted glass texture with grain.
   - `2` - **Mica**: Windows 11 signature backdrop mica (recommended for Windows 11).
   - `3` - **Blur (Clear)**: High-transparency clear glass.
   - `4` - **MicaAlt**: Alternative high-contrast mica for tabs & address bar.
2. **Tweak UI Switches**:
   - `clearAddress`: Transparent address & search bar.
   - `clearBarBg`: Transparent scrollbars and navigation pane.
   - `clearWinUIBg`: Clean WinUI / XAML modern header background (Win 11 23H2/24H2).
   - `showLine`: Control TreeView splitter border.
3. Click **"Apply Blur Effect"**! File Explorer will restart with the new effect active.
4. To undo, simply click **"Undo / Remove Effect"**! File Explorer reverts to stock appearance.

---

## 🔗 Customizing GitHub & Website Links

The app features prominent buttons linking to your **GitHub Profile** and **Personal Website**.
* Click the **"Edit Links"** button or the gear icon in the top header.
* Enter your custom GitHub URL, Website URL, and display labels.
* Click **"Save Changes"**. Your links are stored in `user_links.json` and persist across sessions.

---

## 📁 Project Structure

```
TranslucentTabs/
├── app.py              # Backend API server & Windows system controller
├── user_links.json     # Saved GitHub, Website & profile URLs
├── run.bat             # One-click standard launcher
├── run_admin.bat       # One-click administrator launcher
├── bin/                # ExplorerBlurMica core engine binaries
│   ├── ExplorerBlurMica.dll  # x64 COM Shell Extension DLL
│   ├── config.ini            # Live effect & RGBA configuration
│   ├── register.cmd          # Native registration script
│   └── uninstall.cmd         # Native unregistration script
├── static/             # Modern Fluent UI
│   ├── index.html      # Glassmorphic layout
│   ├── style.css       # UI / UX Pro Max design tokens & animations
│   └── app.js          # Reactive controller, slider math & toasts
└── README.md           # Documentation
```

---

## ⚙️ Requirements & Compatibility

* **Operating System**: Windows 10 (1809+) or Windows 11 (21H2, 22H2, 23H2, 24H2).
* **Runtime**: Python 3 (standard library only, no pip dependencies required!).
* **Browser Window**: Built-in Microsoft Edge (App Mode) or modern Chromium browser.
* **Third-Party Shells**: Fully compatible with StartAllBack, OldNewExplorer, and custom visual themes.

---

## 📜 Credits & License

* Transparency core: [Maplespe/ExplorerBlurMica](https://github.com/Maplespe/ExplorerBlurMica) (LGPL-3.0 License).
* UI Design & Studio Controller: Created with Google Antigravity `ui-ux-pro-max` guidelines.
